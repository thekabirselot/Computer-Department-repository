<?php
                //host   username  pass database  //die is an exit funtion that sends a message
$con= new mysqli('localhost','root','','exam')or die("Could not connect to mysql".mysqli_error($con));
// mysqli connection method to establish connection with database


?>