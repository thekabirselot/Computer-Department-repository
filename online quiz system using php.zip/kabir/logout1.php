<?php 
session_start(); //creates new session
if(isset($_SESSION['email'])){  //check whether variable is set, returns true if already set and not null else false
session_destroy();} //destroys all session data 
$ref= @$_GET['q']; //$ is used to declare variable //@$_Get method is used for collecting data from HTMl form
header("location:admin.php");
?>